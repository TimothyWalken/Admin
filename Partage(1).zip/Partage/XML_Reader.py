# -*- coding: utf-8 -*-
from lxml import etree

#affichage des dates
tree = etree.parse("Test.xml")
for date in tree.xpath("/info/date/"):
    print(date.text)

#affichage du CPU
for CPU in tree.xpath("/info/CPU/"):
	print(CPU.text)

#affichage de la machine concernée
for Nom_Machine in tree.xpath("/info/Nom_Machine/"):
	print(Nom_Machine.text)

#affichage utilisation disque
for disque in tree.xpath("/info/disque/"):
	print(disque.text)

#affichage de la RAM
for RAM in tree.xpath("/info/RAM/"):
	print(RAM.text)

#affichage du nombre de process
for nombre_process in tree.xpath("/info/nombre_process/"):
	print(nombre_process.text)

#affichage du nombre de process system
for nombre_process_systeme in tree.xpath("/info/nombre_process_systeme/"):
	print(nombre_process_systeme.text)

#affichage du nombre d'utilisateurs
for utilisateurs in tree.xpath("/info/utilisateurs/"):
	print(utilisateurs.text)

