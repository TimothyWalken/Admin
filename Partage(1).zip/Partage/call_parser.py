import os
import re

os.system("python HTMLparser.py | grep -e '^/site/CERTFR-2017-ALE-' | grep -e '.html$'")

