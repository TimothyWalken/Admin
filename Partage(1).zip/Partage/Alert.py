# -*- coding: utf-8 -*-

from lxml import etree
from subprocess import call

tree = etree.parse("data.xml")

tabD=[]
#affichage des dates
for date in tree.xpath("/infos/info/date"):
    tabD.append(date.text)

tabNM=[]
#affichage de la machine concernée
for Nom_Machine in tree.xpath("/infos/info/Nom_Machine"):
	tabNM.append(Nom_Machine.text)

tabC=[]
#affichage du CPU
for CPU in tree.xpath("/infos/info/CPU"):
	tabC.append(CPU.text)

tabDI=[]
#affichage utilisation disque
for disque in tree.xpath("/infos/info/disque"):
	tabDI.append(disque.text)

tabR=[]
#affichage de la RAM
for RAM in tree.xpath("/infos/info/RAM"):
	tabR.append(RAM.text)

tabNP=[]
#affichage du nombre de process
for nombre_process in tree.xpath("/infos/info/nombre_process"):
	tabNP.append(nombre_process.text)

tabNPS=[]
#affichage du nombre de process system
for nombre_process_systeme in tree.xpath("/infos/info/nombre_process_systeme"):
	tabNPS.append(nombre_process_systeme.text)

tabNPU=[]
#affichage du nombre de process system
for nombre_process_user in tree.xpath("/infos/info/nombre_process_user"):
	tabNPU.append(nombre_process_user.text)

tabU=[]
#affichage du nombre d'utilisateurs
for utilisateurs in tree.xpath("/infos/info/utilisateurs"):
	tabU.append(utilisateurs.text)


tree = etree.parse("config_alerte.xml")
for alert in tree.xpath("/config/CPU"):
	alertCPU=alert.text

for alert in tree.xpath("/config/RAM"):
	alertRAM=alert.text

for alert in tree.xpath("/config/Dsk"):
	alertDSK=alert.text

for alert in tree.xpath("/config/Process"):
	alertPRS=alert.text

for alert in tree.xpath("/config/User"):
	alertUSR=alert.text


alrtC=[]
alrtR=[]
alrtDI=[]
alrtNP=[]
alrtU=[]


j = len(tabD)
for i in range(0, j):
	if(float(tabC[i]) > float(alertCPU)):
		alrtC.append(tabD[i])

	if(float(tabR[i]) > float(alertRAM)):
		alrtR.append(tabD[i])

	if(float(tabDI[i]) > float(alertDSK)):
		alrtDI.append(tabD[i])

	if(float(tabNP[i]) > float(alertPRS)):
		alrtNP.append(tabD[i])

	if(float(tabU[i]) > float(alertUSR)):
		alrtU.append(tabD[i])


j = len(alrtC)
if(int(j) >= int(1)):
	for i in range(0, j):
		print("a")
		call(["python", "Mail_Send.py"])

j = len(alrtR)
if(int(j) >= int(1)):
	for i in range(0, j):
		print("b")
		call(["python", "Mail_Send.py"])

j = len(alrtDI)
if(int(j) >= int(1)):
	for i in range(0, j):
		print("c")
		call(["python", "Mail_Send.py"])

j = len(alrtNP)
if(int(j) >= int(1)):
	for i in range(0, j):
		print("d")
		call(["python", "Mail_Send.py"])

j = len(alrtU)
if(int(j) >= int(1)):
	for i in range(0, j):
		print("e")
		call(["python", "Mail_Send.py"])
