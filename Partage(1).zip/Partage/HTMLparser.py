import os
import re
from bs4 import BeautifulSoup
from urllib2 import urlopen
#-*- coding: utf-8 -*-

# def GetDocument():
# 	os.system('wget http://www.cert.ssi.gouv.fr/')

html=urlopen("http://www.cert.ssi.gouv.fr/")
soup=BeautifulSoup(html,"html5lib")
for a in soup.find_all('a'):
	vary=a.get("href")
	print vary

