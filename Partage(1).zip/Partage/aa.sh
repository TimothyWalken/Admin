#!/bin/bash

scp uapv1502017@10.104.27.110:/home/etudiants/inf/uapv1502017/public_html/OPENBAR/salut /home/etudiants/inf/uapv1504061/public_html/