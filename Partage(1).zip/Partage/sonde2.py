import os
import commands
from subprocess import call

date1=commands.getoutput('date +%d\ ')
date2=commands.getoutput('date +%m\ ')
date3=commands.getoutput('date +%Y\ %H:%M')
host=commands.getoutput('hostname')

date=date1+"\/"+date2+"\/"+date3

var="s/<date>\/<\/date>/<date>"+date+"<\/date>/g"
call(["sed", "-i","-e",var,"info.xml"])

var2="s/<Nom_Machine>\/<\/Nom_Machine>/<Nom_Machine>"+host+"<\/Nom_Machine>/g"
call(["sed", "-i","-e",var2,"info.xml"])
