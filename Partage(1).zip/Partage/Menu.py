from lxml import etree
import pygal
from subprocess import call

tree = etree.parse("data.xml")

tabD=[]
#affichage des dates
for date in tree.xpath("/infos/info/date"):
    tabD.append(date.text)

tabNM=[]
#affichage de la machine concernée
for Nom_Machine in tree.xpath("/infos/info/Nom_Machine"):
	tabNM.append(Nom_Machine.text)

tabC=[]
#affichage du CPU
for CPU in tree.xpath("/infos/info/CPU"):
	tabC.append(CPU.text)

tabDI=[]
#affichage utilisation disque
for disque in tree.xpath("/infos/info/disque"):
	tabDI.append(disque.text)

tabR=[]
#affichage de la RAM
for RAM in tree.xpath("/infos/info/RAM"):
	tabR.append(RAM.text)

tabNP=[]
#affichage du nombre de process
for nombre_process in tree.xpath("/infos/info/nombre_process"):
	tabNP.append(nombre_process.text)

tabNPS=[]
#affichage du nombre de process system
for nombre_process_systeme in tree.xpath("/infos/info/nombre_process_systeme"):
	tabNPS.append(nombre_process_systeme.text)

tabNPU=[]
#affichage du nombre de process system
for nombre_process_user in tree.xpath("/infos/info/nombre_process_user"):
	tabNPU.append(nombre_process_user.text)

tabU=[]
#affichage du nombre d'utilisateurs
for utilisateurs in tree.xpath("/infos/info/utilisateurs"):
	tabU.append(utilisateurs.text)

call(["clear"])

print("\033[31m * Bienvenue ! * \033[0m \n")

def Menu():
	print("\033[32m Que souhaitez-vous faire ? \033[0m")
	print("\033[34m1\033[0m - Afficher les infos d'une machine")
	print("\033[34m2\033[0m - Créer un graphe d'une machine")
	print("\033[34m0\033[0m - Quitter")
	z = raw_input('> ')
	print("\n")
	if(z == "1"):
		info_machine()
	elif(z == "2"):
		graph()
	elif(z == "0"):
		print("Au revoir ! :-) ")
		exit()
	else:
		print("Cette catégorie n'éxiste pas !")

	Menu()

def info_machine():

	call(["clear"])
	print("Voici la liste des machines du parc :")

	fichier = open("machines.txt","r")
	lignes = fichier.readlines()
	fichier.close()

	dico=dict()
	type(dico)
	for ligne in lignes:
		dico[ligne[:-1]]="x"


	for Mach in dico:
		j = len(tabD)
		for i in range(0, j):
			if tabNM[i] == Mach:
				dico[Mach]=tabD[i]

	test=1

	while test == 1 :
		for Mach in dico:
			print(Mach)

		print("\n")
		x = raw_input('\033[32m* Quelle machine voulez vous visioner ? (Saisissez le nom de la machine)\033[0m\n')
		for Mach in dico:
			if Mach == x :
				test=0

		if test == 1 :
			print("Rentrer un nom de machine valide !")


	print("\033[0m\033[35mEtat de la machine : " + x + ", date: "+dico[x])

	j = len(tabD)
	for i in range(0, j):
		if tabNM[i] == x :
			if dico[x] == tabD[i] :
				print("CPU:"+tabC[i])
				print("RAM:"+tabR[i])
				print("Disque:"+tabDI[i])
				print("Processur executés:"+tabNP[i])
				print("Dont, en processus systeme:"+tabNPS[i])
				print("Et, en processus utilisateur:"+tabNPU[i])
				print("Utilisateurs:"+tabU[i])
				print("\033[0m\n")

	Menu()

def graph():

	call(["clear"])
	fichier = open("machines.txt","r")
	lignes = fichier.readlines()
	fichier.close()
	machin=[]
	print("Liste des machines du parc : \n")
	for ligne in lignes:
		machin.append(ligne[:-1])
		print(ligne[:-1])

		test=1


	while test == 1 :
		x = raw_input('\033[32m* De quelle machine voulez vous faire le graph ?\033[0m\n')
		print("\n")

		for thing in machin:
			if(x == thing):
				test=0

		if(test==1):
			print('Machine inexistante !')

	tabCM=[]
	tabRM=[]
	tabDM=[]

	j = len(tabD)
	for i in range(0, j):
		if tabNM[i] == x :
			tabCM.append(float(tabC[i]))
			tabRM.append(float(tabR[i]))
			tabDM.append(float(tabDI[i]))

	line_chart = pygal.Bar()
	line_chart.title = 'Informations about machine '
	line_chart.add('CPU',	tabCM)
	line_chart.add('RAM',	tabRM)
	line_chart.add('Disk',	tabDM)
	line_chart.render_to_file('StatMachine.svg')
	print("\033[35mGraphe créer ! Consulter StatMachine.svg\033[0m\n")
	Menu()

Menu()
