#!usr/bin/env python

#SEND EMAIL TO SOMEONE

import os 
import smtplib 
import getpass 
import sys

mail = 'gmail'
user = 'workfac0@gmail.com'
passwd = 'trytry84'
nomac = 'MACHINE 1'


# mail ='univ-avignon'
# user ='amaury.huot@alumni.univ-avignon.fr'
# passwd='98t8abs5'
# nomac ='MACHINE 2'

to = 'ZeR0-AbSoLu@protonmail.com'
subject = 'SYSTEM ALERT !!!'
# body = 'AN ALERT HAS BEEN SEND FROM THE MACHINE : ' + nomac
with open('skeleton.txt', 'r') as myfile:
    body=myfile.read().replace('\n', '') + nomac
try:     
    mail = smtplib.SMTP('smtp.gmail.com',587) 
    #mail = smtplib.SMTP('smtpz.univ-avignon.fr',465)     
    mail.ehlo()              
    mail.starttls()     
    mail.login(user,passwd)                
    msg = 'From: ' + user + '\nSubject: ' + subject + '\n' + body         
    mail.sendmail(user,to,msg)               
    sys.stdout.flush()    
    mail.quit()    
    print 'SENT !!!\n' 
except KeyboardInterrupt:     
    print '[-] Canceled'     
    sys.exit()
except smtplib.SMTPAuthenticationError:  
    print '\n[!] The username or password you entered is incorrect.'     
    sys.exit()

