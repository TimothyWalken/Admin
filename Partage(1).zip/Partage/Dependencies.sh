#!/bin/bash
#Dependencies installer
#Virtual Box dependencies Installation script for Project Usage
#-codé par ZeR0-#
#-*- coding: utf-8 -*-
sudo pip install --upgrade pip
sudo pip install beautifulsoup4 && sudo pip install lxml && sudo pip install psutil && sudo pip install smtplib


