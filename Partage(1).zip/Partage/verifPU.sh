#!/bin/bash

nbprocess=$(ps -A | wc -l)
nbprocess=$(($nbprocess - 1))

if [ $nbprocess -ge 350 ]
	then
	echo "!!! WARNING [ $nbprocess ] sont lancés, envoi du message d'urgence à la base !!!";
else
	echo "Nombre de processus total : [ $nbprocess ]";
fi

psys=$(ps -A | awk '{print ($2)}')
nbpsys=0
for elem in $psys
do
	if test $elem = '?'
	then
		nbpsys=$(($nbpsys + 1))
	fi
done

echo "Dont [ $nbpsys ] processus systeme";

nbpuser=$(ps -u | wc -l)
nbpuser=$(($nbpuser -1))
echo "Nombre de processus lancés par l'utilisateur actuel: [ $nbpuser ]";

userco=$(users | wc -w)
if [ $userco -ge 30 ]
	then
	echo "!!!WARNING [ $userco ] utilisateurs sont connectés, envoi du message d'urgence !!!"
else
	echo "Il y a actuellement [ $userco ] utilisateur(s) connecté(s)";
	fi

sed -i -e "s/<nombre_process>\/<\/nombre_process>/<nombre_process>$nbprocess<\/nombre_process>/g" data.xml
sed -i -e "s/<nombre_process_systeme>\/<\/nombre_process_systeme>/<nombre_process_systeme>$nbpsys<\/nombre_process_systeme>/g" data.xml
sed -i -e "s/<nombre_process_user>\/<\/nombre_process_user>/<nombre_process_user>$nbpuser<\/nombre_process_user>/g" data.xml
sed -i -e "s/<utilisateurs>\/<\/utilisateurs>/<utilisateurs>$userco<\/utilisateurs>/g" data.xml